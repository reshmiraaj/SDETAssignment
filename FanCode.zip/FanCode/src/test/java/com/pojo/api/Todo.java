package com.pojo.api;

public class Todo {
	private int id;
	private boolean completed;

	public int getId() {
		return id;
	}

	public boolean isCompleted() {
		return completed;
	}
}